package one.digitalinnovation.gof.facade;

import subsistema1.crm.CrmService;
import subsistema2.cep.CepApi;

public class Facade {

	public void migrarCliente(String nome, String cep) {
		// validação simples que adicionei, pra não mandar cliente incompleto pro CRM
		if (nome == null || nome.isEmpty() || cep == null || cep.isEmpty()) {
			System.out.println("Nome e CEP são obrigatórios para migrar o cliente.");
			return;
		}
		
		String cidade = CepApi.getInstancia().recuperarCidade(cep);
		String estado = CepApi.getInstancia().recuperarEstado(cep);
		
		CrmService.gravarCliente(nome, cep, cidade, estado);
	}
}
