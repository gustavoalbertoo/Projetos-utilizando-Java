package one.digitalinnovation.gof.strategy;

// comportamento novo que adicionei, só pra mostrar que dá pra criar
// quantas estratégias eu quiser sem precisar mexer na classe Robo
public class ComportamentoCauteloso implements Comportamento {

	@Override
	public void mover() {
		System.out.println("Movendo-se cautelosamente...");
	}

}
