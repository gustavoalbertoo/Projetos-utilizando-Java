package one.digitalinnovation.gof.singleton;

/**
 * Singleton "preguiçoso".
 * 
 * @author falvojr
 */
public class SingletonLazy {

	private static SingletonLazy instancia;
	
	private SingletonLazy() {
		super();
	}
	
	public static SingletonLazy getInstancia() {
		// obs: essa versão não é thread-safe (se duas threads chamarem
		// getInstancia() ao mesmo tempo, dá pra criar mais de uma instância).
		// deixei assim mesmo pra comparar com a versão LazyHolder, que resolve isso.
		if (instancia == null) {
			instancia = new SingletonLazy();
		}
		return instancia;
	}
}
