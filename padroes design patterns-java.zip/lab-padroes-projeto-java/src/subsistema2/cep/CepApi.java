package subsistema2.cep;

public class CepApi {

	private static CepApi instancia = new CepApi();

	private CepApi() {
		super();
	}

	public static CepApi getInstancia() {
		return instancia;
	}
	
	public String recuperarCidade(String cep) {
		// continua sendo uma simulação (não bate numa API de verdade),
		// mas agora varia um pouco a cidade de acordo com o prefixo do cep
		if (cep.startsWith("01")) {
			return "São Paulo";
		} else if (cep.startsWith("13")) {
			return "Campinas";
		}
		return "Araraquara";
	}
	
	public String recuperarEstado(String cep) {
		return "SP";
	}
}
