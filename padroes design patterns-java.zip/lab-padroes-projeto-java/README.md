# Explorando Padrões de Projetos na Prática com Java

Repositório com as implementações dos padrões de projeto explorados no Lab "Explorando Padrões de Projetos na Prática com Java". Especificamente, este projeto explorou alguns padrões usando Java puro:
- Singleton
- Strategy
- Facade

## Evoluções feitas em cima do lab original

Depois de reproduzir o código do lab, fiz algumas pequenas alterações para praticar mais os conceitos:

- **CepApi (Facade):** em vez de sempre devolver "Araraquara/SP", agora a cidade varia um pouco de acordo com o prefixo do CEP informado.
- **Facade:** adicionei uma validação simples para não deixar migrar cliente com nome ou CEP vazio.
- **Strategy:** criei um novo comportamento, `ComportamentoCauteloso`, só para reforçar que o `Robo` não precisa mudar quando surge uma nova estratégia.
- **SingletonLazy:** deixei um comentário explicando que essa versão não é thread-safe, ao contrário da versão LazyHolder.
