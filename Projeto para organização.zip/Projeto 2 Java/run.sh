#/bin/sh
javac -d out $(find . -name "*.java") && java -cp out MainApl2
