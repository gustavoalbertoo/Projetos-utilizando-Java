// Integrantes:
// Gabriel da Silva Coelho (10748434)
// Gabriel Mello Aristides (10736402)
// Gustavo Rodrigues Alberto (10738010)
// Lucas Oliveira (10736078)

package apl2;

public class Operation {

	/**
	 * <p>
	 * Recebe como parâmetro uma lista encadeada do tipo {@code LinkedListOriginal},
	 * sendo que os nós da lista estão
	 * populados com o conteúdo da base de dados original (conteúdo do arquivo
	 * dados.txt).
	 * </p>
	 * <p>
	 * A operação {@code map()} deve mapear os dados originais para uma lista
	 * encadeada do tipo {@code DLinkedList} e
	 * retornar a referência da {@code DLinkedList} que possui os dados mapeados
	 * para a nova estrutura usada pelo sistema de notas.
	 * </p>
	 *
	 * @param original Base de dados original carregada em uma
	 *                 {@code LinkedListOriginal}.
	 * @return Uma nova {@code DLinkedList} que contém o mapeamento da coleção de
	 *         dados {@code original} para a nova estrutura usada pelo sistema de
	 *         notas.
	 */
	public static DLinkedList map(final LinkedListOriginal original) {
		if (original.count() < 1) {
			return new DLinkedList();
		}

		DLinkedList DLK = new DLinkedList();
		NodeOriginal pont = original.getHead();

		while (pont != null) {
			String id = "26.S1-" + String.valueOf(pont.getId());
			String nome = pont.getNome();
			float nota = (pont.getInteiro() < 0 || pont.getDecimo() < 0) ? 99.9f
					: pont.getInteiro() + (pont.getDecimo() / 10.0f);

			DLK.append(id, nome, nota);
			pont = pont.getNext();
		}
		return DLK;
	}

	/**
	 * <p>
	 * Recebe como parâmetro uma lista duplamente encadeada do tipo
	 * {@code DLinkedList}, sendo que os nós da lista estão
	 * populados com o resultado da operação {@code map()}.
	 * </p>
	 * <p>
	 * A operação {@code filterRemoveNonGraded()} deve filtrar os nós que não
	 * possuem notas válidas (caso de "ausência de nota")
	 * e retornar uma nova lista do tipo {@code DLinkedList} contendo apenas os nós
	 * com notas válidas.
	 * </p>
	 * * @param data Base de dados mapeada para o formato {@code DLinkedList} (via
	 * operação {@code map()}).
	 * 
	 * @return Uma nova {@code DLinkedList} que contém a coleção de dados
	 *         ({@code data}) filtrada com nós que possuem apenas pessoas com notas
	 *         válidas.
	 */
	public static DLinkedList filterRemoveNonGraded(final DLinkedList data) {
		DLinkedList DLK = new DLinkedList();
		Node pont = data.getHead();

		while (pont != null) {
			if (pont.getNota() != 99.9f) {
				DLK.append(pont.getId(), pont.getNome(), pont.getNota());
			}
			pont = pont.getNext();
		}

		return DLK;
	}

	/**
	 * <p>
	 * Recebe como parâmetro uma lista duplamente encadeada do tipo
	 * {@code DLinkedList}, sendo que os nós da lista estão
	 * populados com o resultado da operação {@code map()}.
	 * </p>
	 * <p>
	 * A operação {@code filterRemoveGraded()} deve filtrar os nós que possuem notas
	 * válidas e retornar uma nova lista do
	 * tipo {@code DLinkedList} contendo apenas os nós com notas inválidas (caso de
	 * "ausência de nota").
	 * </p>
	 *
	 * @param data Base de dados mapeada para o formato {@code DLinkedList} (via
	 *             operação {@code map()}).
	 * @return Uma nova {@code DLinkedList} que contém a coleção de dados
	 *         ({@code data}) filtrada com nós que possuem apenas pessoas com notas
	 *         inválidas.
	 */
	public static DLinkedList filterRemoveGraded(final DLinkedList data) {
		DLinkedList DLK = new DLinkedList();
		Node pont = data.getHead();

		while (pont != null) {
			if (pont.getNota() == 99.9f) {
				DLK.append(pont.getId(), pont.getNome(), pont.getNota());
			}
			pont = pont.getNext();
		}

		return DLK;
	}

	/**
	 * <p>
	 * Recebe como parâmetro uma lista duplamente encadeada do tipo
	 * {@code DLinkedList}, sendo que os nós da lista estão
	 * populados com o resultado da operação {@code filterRemoveNonGraded()}, e a
	 * média de notas válidas, calculadas com a
	 * operação {@code reduce()}.
	 * </p>
	 * <p>
	 * A operação {@code filterRemoveBelowAverage()} deve filtrar os nós que possuem
	 * notas abaixo da média e retornar uma
	 * nova lista do tipo {@code DLinkedList} contendo apenas os nós com notas acima
	 * da média.
	 *
	 * @param data    Base de dados filtrada com a operação
	 *                {@code filterRemoveNonGraded()}.
	 * @param average Média de notas válidas calculada com a operação
	 *                {@code reduce()}.
	 * @return Uma nova {@code DLinkedList} que contém a coleção de dados
	 *         ({@code data}) filtrada somente com pessoas com notas maiores do que
	 *         {@code average}.
	 */
	public static DLinkedList filterRemoveBelowAverage(final DLinkedList data, float average) {
		DLinkedList DLK = new DLinkedList();
		Node pont = data.getHead();

		while (pont != null) {
			if (pont.getNota() > average) {
				DLK.append(pont.getId(), pont.getNome(), pont.getNota());
			}
			pont = pont.getNext();
		}

		return DLK;
	}

	/**
	 * <p>
	 * Recebe como parâmetro uma lista duplamente encadeada do tipo
	 * {@code DLinkedList}, sendo que os nós da lista estão
	 * populados com o resultado da operação {@code filterRemoveNonGraded()}.
	 * </p>
	 * <p>
	 * A operação {@code reduce()} deve calcular a média das notas contidas na
	 * coleção de dados passada como parâmetro e
	 * retornar a média calculada.
	 *
	 * @param data Base de dados filtrada com a operação
	 *             {@code filterRemoveNonGraded()}.
	 * @return Média das notas ({@code float}) contidas na coleção de dados
	 *         ({@code data}).
	 */
	public static float reduce(final DLinkedList data) {
		if (data.count() < 1) {
			return -1;
		}

		Node pont = data.getHead();
		float average = 0;

		while (pont != null) {
			average += pont.getNota();
			pont = pont.getNext();
		}

		return average / data.count();

	}

	/**
	 * <p>
	 * Recebe como parâmetro uma lista duplamente encadeada do tipo
	 * {@code DLinkedList}, sendo que os nós da lista estão
	 * populados com o resultado da operação {@code map()}.
	 * </p>
	 * <p>
	 * A operação {@code mapToString()} deve mapear todos os nós da coleção de dados
	 * passada como parâmetro para uma única
	 * {@code String}, sendo que cada dado de uma pessoa é separado por
	 * ponto-e-vírgula (;) e cada pessoa é separada por uma
	 * quebra de linha.
	 * </p>
	 *
	 * @param data Base de dados mapeada para o formato {@code DLinkedList} (via
	 *             operação {@code map()}).
	 * @return {@code String} com a coleção de dados separada por ponto-e-vírgula
	 *         (dados de cada pessoa) e quebras de linha (cada pessoa).
	 */
	public static String mapToString(final DLinkedList data) {
		if (data == null || data.count() < 1) {
			return "";
		}

		StringBuilder sb = new StringBuilder();
		Node pont = data.getHead();

		while (pont != null) {
			sb.append(pont.getId()).append(";")
					.append(pont.getNome()).append(";")
					.append(pont.getNota());

			sb.append("\n");
			pont = pont.getNext();
		}
		return sb.toString().trim();
	}

}
