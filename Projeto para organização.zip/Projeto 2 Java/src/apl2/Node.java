// arquivo: src/apl2/Node.java

// Integrantes:
// Gabriel da Silva Coelho (10748434)
// Gabriel Mello Aristides (10736402)
// Gustavo Rodrigues Alberto (10738010)
// Lucas Oliveira (10736078)

package apl2;

public class Node {
	private String id;
	private String nome;
	private float nota;
	private Node previous;
	private Node next;

	public Node() {
		this("", "", 0.0f, null, null);
	}

	public Node(String id, String nome, float nota, Node previous, Node next) {
		this.id = id;
		this.nome = nome;
		this.nota = nota;
		this.previous = previous;
		this.next = next;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		// TODO: checar se esse pedaço é realmente necessário
		// if (id > 0 && id < 1000){
		// this.id = id;
		// } else {
		// print("Não é possível inserir esse ID pois ele está fora do alcance de IDs
		// permitidos.");
		// }
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public float getNota() {
		return nota;
	}

	public void setNota(float nota) {
		this.nota = nota;
	}

	public Node getPrevious() {
		return previous;
	}

	public void setPrevious(Node previous) {
		this.previous = previous;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}

	@Override
	public String toString() {
		return "[dados: (" + id + ";" + nome + ";" + nota + ")]";
	}
}
