# Academia - Sistema de Gerenciamento em Java

Simulação em terminal de um sistema de gerenciamento de academia, escrito em
Java puro (sem frameworks, sem banco de dados). O projeto é uma releitura de
uma versão anterior feita em Swift, adaptando as mesmas ideias para os
recursos da linguagem Java.

## Sobre o projeto

O sistema modela o dia a dia de uma academia: cadastro de alunos e
instrutores, planos de assinatura, turmas coletivas, sessões de personal
trainer, equipamentos e manutenção. Tudo roda a partir de um único método
`main`, que simula um cenário de uso real, incluindo tentativas inválidas
para mostrar as regras de negócio sendo aplicadas.

## Requisitos

- JDK 17 ou superior instalado (o projeto foi testado com o JDK 21)

Para checar se o Java está instalado:

```bash
java -version
javac -version
```

## Estrutura de pastas

O código é organizado em pacotes por responsabilidade, dentro de `src/`:

```
academia-java/
├── README.md
└── src/
    ├── Main.java                 -> ponto de entrada, roteiro de simulação
    ├── modelo/
    │   ├── Pessoa.java           -> classe base de Aluno e Instrutor
    │   ├── Aluno.java
    │   ├── Instrutor.java
    │   └── PlanoAssinatura.java
    ├── enums/
    │   ├── NivelExperiencia.java
    │   ├── CategoriaAula.java
    │   └── StatusEquipamento.java
    ├── aulas/
    │   ├── Aula.java              -> contrato base
    │   ├── TurmaColetiva.java
    │   └── TreinoPersonal.java
    ├── equipamentos/
    │   ├── Manutivel.java         -> contrato base
    │   └── Equipamento.java
    ├── relatorios/
    │   └── RelatorioMetricas.java
    └── academia/
        └── Academia.java          -> fachada do sistema
```

`Main.java` fica solto na raiz de `src/` (pacote padrão), já que é só o
ponto de entrada. Todo o resto do domínio está separado por pacote.

## Como compilar e rodar

A partir da pasta raiz do projeto (onde fica a pasta `src/`):

```bash
javac -encoding UTF-8 -d bin $(find src -name "*.java")
java -cp bin Main
```

O primeiro comando compila todos os `.java` (de todos os pacotes) e coloca
os `.class` gerados dentro da pasta `bin`, mantendo a mesma estrutura de
pastas. O segundo comando executa a simulação.

Se preferir, dá pra compilar sem o `find`, listando os pacotes na mão:

```bash
javac -encoding UTF-8 -d bin src/Main.java src/modelo/*.java src/enums/*.java src/aulas/*.java src/equipamentos/*.java src/relatorios/*.java src/academia/*.java
java -cp bin Main
```

## Responsabilidade de cada pacote

| Pacote | Responsabilidade |
|---|---|
| `modelo` | Pessoas cadastradas (`Pessoa`, `Aluno`, `Instrutor`) e o `PlanoAssinatura` que elas contratam. |
| `enums` | Os três conjuntos fechados de valores do sistema: nível do aluno, categoria de aula e status de equipamento. |
| `aulas` | O contrato `Aula` e suas duas implementações, `TurmaColetiva` e `TreinoPersonal`. |
| `equipamentos` | O contrato `Manutivel` e o `Equipamento`, que é quem de fato passa por manutenção. |
| `relatorios` | O `RelatorioMetricas`, retrato consolidado da academia. |
| `academia` | A fachada `Academia`, que centraliza cadastros, agendamentos e regras de negócio. |
| *(raiz)* | `Main.java`, o roteiro de simulação. |

## Decisões de design

**Herança para pessoas, interface para aulas.** `Aluno` e `Instrutor`
herdam de `Pessoa` porque compartilham a mesma natureza (dados pessoais de
alguém cadastrado na academia). Já `TurmaColetiva` e `TreinoPersonal` são
conceitualmente diferentes entre si (uma tem lista de inscritos e
capacidade, a outra é individual e agendada), então elas assinam a
interface `Aula` em vez de herdar de uma classe comum. Isso permite tratar
as duas de forma uniforme em uma lista, sem forçar uma hierarquia que não
faz sentido.

**Fachada central.** A classe `Academia` concentra os dados em mapas
(`HashMap`), usando matrícula, CREF e número de série como chaves. Isso
evita duplicar lógica de busca espalhada pelo código e deixa claro onde
ficam as regras de negócio.

**Regras de negócio como retorno booleano.** Métodos como
`matricularAluno`, `contratarInstrutor` e `agendarPersonal` retornam
`boolean` e imprimem a mensagem de erro quando bloqueiam alguma operação
(matrícula duplicada, e-mail duplicado, turma lotada, plano sem personal).
Não há exceções customizadas de propósito, para manter o fluxo simples de
acompanhar.

**Manutenção condicional.** Um equipamento só pode ser reparado se o
status dele for `DEFEITUOSO`. A manutenção em lote tenta reparar todos os
equipamentos cadastrados e separa, no relatório final, o que foi
consertado do que não precisava de reparo.

**Pacotes por domínio, não por tipo.** A separação em `modelo`, `aulas`,
`equipamentos`, `relatorios` e `academia` segue o assunto de cada classe,
não se ela é uma interface, uma classe comum ou um enum. Por exemplo,
`Manutivel` (interface) e `Equipamento` (classe) ficam juntos em
`equipamentos`, porque fazem parte do mesmo conceito.

## O que a simulação demonstra

Ao rodar `Main`, o programa executa nesta ordem:

1. Monta um catálogo fixo de planos de assinatura
2. Contrata dois instrutores e tenta contratar um terceiro com CREF
   repetido (bloqueado)
3. Matricula dois alunos e tenta matricular um terceiro com e-mail
   repetido (bloqueado)
4. Cadastra três equipamentos, dois deles com defeito
5. Abre uma turma coletiva com capacidade para dois alunos e tenta
   inscrever um terceiro (bloqueado)
6. Agenda personal trainer para uma aluna cujo plano inclui o benefício
   (permitido) e para um aluno cujo plano não inclui (bloqueado)
7. Executa a manutenção em lote nos equipamentos
8. Lista todas as pessoas cadastradas, tratando alunos e instrutores de
   forma uniforme
9. Lista todas as aulas ativas, tratando turmas e personais de forma
   uniforme
10. Gera e imprime o relatório final de métricas da academia
