package enums;

// Categoria da aula, seja ela coletiva ou personal
public enum CategoriaAula {
    MUSCULACAO,
    FUNCIONAL,
    LUTA,
    DANCA,
    YOGA,
    CARDIO
}
