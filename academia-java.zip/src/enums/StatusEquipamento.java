package enums;

// Estado atual de um equipamento
public enum StatusEquipamento {
    FUNCIONANDO,
    DEFEITUOSO,
    EM_MANUTENCAO
}
