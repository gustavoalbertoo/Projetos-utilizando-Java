package enums;

// Nivel de experiencia do aluno na academia
public enum NivelExperiencia {
    INICIANTE,
    INTERMEDIARIO,
    AVANCADO
}
