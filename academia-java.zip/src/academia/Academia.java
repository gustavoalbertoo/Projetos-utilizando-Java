package academia;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import modelo.Pessoa;
import modelo.Aluno;
import modelo.Instrutor;
import equipamentos.Equipamento;
import enums.StatusEquipamento;
import aulas.Aula;
import aulas.TurmaColetiva;
import aulas.TreinoPersonal;
import relatorios.RelatorioMetricas;

// Fachada do sistema: cadastros, agendamentos, manutenção e relatórios
public class Academia {

    private final Map<String, Aluno> alunosPorMatricula = new HashMap<>();
    private final Map<String, Instrutor> instrutoresPorCref = new HashMap<>();
    private final Map<String, Equipamento> equipamentosPorNumeroSerie = new HashMap<>();
    private final List<Aula> aulas = new ArrayList<>();
    private final List<TreinoPersonal> sessoesPersonal = new ArrayList<>();

    // Admissão de alunos e instrutores

    // Bloqueia matrícula duplicada e e-mail duplicado ao mesmo tempo
    public boolean matricularAluno(Aluno aluno) {
        if (alunosPorMatricula.containsKey(aluno.getMatricula())) {
            System.out.println("[Erro] Já existe um aluno com a matrícula " + aluno.getMatricula());
            return false;
        }

        if (emailJaCadastrado(aluno.getEmail())) {
            System.out.println("[Erro] Já existe uma pessoa cadastrada com o e-mail " + aluno.getEmail());
            return false;
        }

        alunosPorMatricula.put(aluno.getMatricula(), aluno);
        System.out.println("Aluno matriculado: " + aluno.descricao());
        return true;
    }

    // Mesma proteção dupla de matrícula/CREF e e-mail
    public boolean contratarInstrutor(Instrutor instrutor) {
        if (instrutoresPorCref.containsKey(instrutor.getCref())) {
            System.out.println("[Erro] Já existe um instrutor com o CREF " + instrutor.getCref());
            return false;
        }

        if (emailJaCadastrado(instrutor.getEmail())) {
            System.out.println("[Erro] Já existe uma pessoa cadastrada com o e-mail " + instrutor.getEmail());
            return false;
        }

        instrutoresPorCref.put(instrutor.getCref(), instrutor);
        System.out.println("Instrutor contratado: " + instrutor.descricao());
        return true;
    }

    private boolean emailJaCadastrado(String email) {
        boolean entreAlunos = alunosPorMatricula.values().stream()
                .anyMatch(a -> a.getEmail().equalsIgnoreCase(email));
        boolean entreInstrutores = instrutoresPorCref.values().stream()
                .anyMatch(i -> i.getEmail().equalsIgnoreCase(email));
        return entreAlunos || entreInstrutores;
    }

    // Equipamentos e manutenção

    public void cadastrarEquipamento(Equipamento equipamento) {
        equipamentosPorNumeroSerie.put(equipamento.getNumeroSerie(), equipamento);
        System.out.println("Equipamento cadastrado: " + equipamento);
    }

    // Tenta reparar todos os equipamentos com defeito e mostra o resultado
    public void realizarManutencaoEmLote() {
        List<Equipamento> reparados = new ArrayList<>();
        List<Equipamento> falharam = new ArrayList<>();

        for (Equipamento equipamento : equipamentosPorNumeroSerie.values()) {
            boolean sucesso = equipamento.realizarReparo("Manutenção preventiva de rotina");
            if (sucesso) {
                reparados.add(equipamento);
            } else {
                falharam.add(equipamento);
            }
        }

        System.out.println("----- Manutenção em lote -----");
        System.out.println("Reparados (" + reparados.size() + "):");
        for (Equipamento e : reparados) {
            System.out.println("  - " + e);
        }
        System.out.println("Não reparados / sem necessidade de reparo (" + falharam.size() + "):");
        for (Equipamento e : falharam) {
            System.out.println("  - " + e);
        }
        System.out.println("-------------------------------");
    }

    // Aulas e agendamento de personal

    public void abrirTurmaColetiva(TurmaColetiva turma) {
        aulas.add(turma);
        System.out.println("Turma coletiva aberta: " + turma.getNomeAula());
    }

    // Só agenda se o plano do aluno incluir personal
    public boolean agendarPersonal(TreinoPersonal sessao) {
        Aluno aluno = sessao.getAluno();

        if (!aluno.getPlano().isIncluiPersonal()) {
            System.out.println("[Erro] O plano " + aluno.getPlano().getNome()
                    + " de " + aluno.getNome() + " não inclui personal trainer.");
            return false;
        }

        sessoesPersonal.add(sessao);
        aulas.add(sessao);
        System.out.println("Personal agendado: " + sessao.getNomeAula() + " - " + sessao.getDescricao());
        return true;
    }

    // Listagens polimórficas

    // Alunos e instrutores tratados como uma única lista de Pessoa
    public void listarPessoas() {
        List<Pessoa> pessoas = new ArrayList<>();
        pessoas.addAll(alunosPorMatricula.values());
        pessoas.addAll(instrutoresPorCref.values());

        System.out.println("----- Pessoas cadastradas -----");
        for (Pessoa pessoa : pessoas) {
            System.out.println("  - " + pessoa.descricao());
        }
        System.out.println("--------------------------------");
    }

    // Turmas e personais tratados de forma uniforme, via contrato Aula
    public void listarAulas() {
        System.out.println("----- Aulas ativas -----");
        for (Aula aula : aulas) {
            System.out.printf("  - [%s] %s (instrutor: %s) - %s%n",
                    aula.getCategoria(), aula.getNomeAula(),
                    aula.getInstrutor().getNome(), aula.getDescricao());
        }
        System.out.println("-------------------------");
    }

    // Relatório de métricas

    public RelatorioMetricas gerarRelatorioMetricas() {
        long defeituosos = equipamentosPorNumeroSerie.values().stream()
                .filter(e -> e.getStatus() == StatusEquipamento.DEFEITUOSO)
                .count();

        double receitaMensal = alunosPorMatricula.values().stream()
                .mapToDouble(a -> a.getPlano().getValorMensal())
                .sum();

        return new RelatorioMetricas(
                alunosPorMatricula.size(),
                instrutoresPorCref.size(),
                aulas.size(),
                sessoesPersonal.size(),
                (int) defeituosos,
                receitaMensal
        );
    }
}
