import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

import modelo.Aluno;
import modelo.Instrutor;
import modelo.PlanoAssinatura;
import enums.NivelExperiencia;
import enums.CategoriaAula;
import enums.StatusEquipamento;
import equipamentos.Equipamento;
import aulas.TurmaColetiva;
import aulas.TreinoPersonal;
import academia.Academia;
import relatorios.RelatorioMetricas;

// Simula um dia de uso da academia via terminal
public class Main {

    public static void main(String[] args) {

        // garante acentos certos em qualquer terminal
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        // Catálogo de planos
        PlanoAssinatura planoMensal = new PlanoAssinatura("Mensal", false, 4, 1, 129.90);
        PlanoAssinatura planoTrimestral = new PlanoAssinatura("Trimestral", true, 8, 3, 109.90);
        PlanoAssinatura planoAnual = new PlanoAssinatura("Anual", true, -1, 12, 89.90);

        System.out.println("===== Catálogo de planos =====");
        for (PlanoAssinatura plano : List.of(planoMensal, planoTrimestral, planoAnual)) {
            System.out.println("  - " + plano);
        }
        System.out.println();

        Academia academia = new Academia();

        // Contratação de instrutores
        System.out.println("===== Contratando instrutores =====");
        Instrutor carla = new Instrutor(
                "Carla Menezes", "carla.menezes@academia.com", "(11) 98888-1122",
                "123.456.789-00", "Rua das Flores, 220",
                "CREF-000123-G/SP", "Musculação", 2019, 4200.00,
                List.of("Segunda", "Quarta", "Sexta")
        );

        Instrutor diego = new Instrutor(
                "Diego Alves", "diego.alves@academia.com", "(11) 97777-3344",
                "987.654.321-00", "Av. Central, 900",
                "CREF-000456-G/SP", "Funcional e Yoga", 2021, 3800.00,
                List.of("Terça", "Quinta", "Sábado")
        );

        academia.contratarInstrutor(carla);
        academia.contratarInstrutor(diego);

        // CREF duplicado, deve bloquear
        Instrutor crefDuplicado = new Instrutor(
                "Outro Instrutor", "outro@academia.com", "(11) 90000-0000",
                "111.222.333-44", "Rua Teste, 1",
                "CREF-000123-G/SP", "Natação", 2022, 3000.00,
                List.of("Segunda")
        );
        academia.contratarInstrutor(crefDuplicado);
        System.out.println();

        // Matrícula de alunos
        System.out.println("===== Matriculando alunos =====");
        Aluno joao = new Aluno(
                "João Pedro Santos", "joao.pedro@email.com", "(11) 96666-1010",
                "222.333.444-55", "Rua das Palmeiras, 45",
                "MAT-0001", planoMensal, NivelExperiencia.INICIANTE,
                82.5, 1.78, "Emagrecimento", true
        );

        Aluno beatriz = new Aluno(
                "Beatriz Lima", "beatriz.lima@email.com", "(11) 95555-2020",
                "333.444.555-66", "Av. Paulista, 1500",
                "MAT-0002", planoAnual, NivelExperiencia.AVANCADO,
                63.0, 1.65, "Hipertrofia", true
        );

        academia.matricularAluno(joao);
        academia.matricularAluno(beatriz);

        // e-mail duplicado, deve bloquear
        Aluno emailDuplicado = new Aluno(
                "Outro Aluno", "joao.pedro@email.com", "(11) 90000-0001",
                "444.555.666-77", "Rua Y, 2",
                "MAT-0003", planoMensal, NivelExperiencia.INICIANTE,
                70.0, 1.70, "Condicionamento", false
        );
        academia.matricularAluno(emailDuplicado);
        System.out.println();

        // Equipamentos
        System.out.println("===== Cadastrando equipamentos =====");
        Equipamento esteira = new Equipamento("EQ-001", "Esteira Ergométrica", StatusEquipamento.DEFEITUOSO);
        Equipamento supino = new Equipamento("EQ-002", "Supino Reto", StatusEquipamento.FUNCIONANDO);
        Equipamento bicicleta = new Equipamento("EQ-003", "Bicicleta Ergométrica", StatusEquipamento.DEFEITUOSO);

        academia.cadastrarEquipamento(esteira);
        academia.cadastrarEquipamento(supino);
        academia.cadastrarEquipamento(bicicleta);
        System.out.println();

        // Turmas coletivas
        System.out.println("===== Abrindo turmas coletivas =====");
        TurmaColetiva funcional = new TurmaColetiva(
                "Funcional em Grupo", diego, CategoriaAula.FUNCIONAL,
                "Treino em circuito focado em resistência", 2
        );
        academia.abrirTurmaColetiva(funcional);

        funcional.matricularAluno(joao);
        funcional.matricularAluno(beatriz);

        // turma cheia, deve bloquear
        Aluno terceiroNaTurma = beatriz; // só reaproveitando para simular a tentativa
        boolean vagaLivre = funcional.matricularAluno(terceiroNaTurma);
        if (!vagaLivre) {
            System.out.println("[Erro] Turma '" + funcional.getNomeAula() + "' está cheia (capacidade "
                    + funcional.getCapacidadeMaxima() + ").");
        }
        System.out.println();

        // Agendamento de personal
        System.out.println("===== Agendando personal =====");
        // Beatriz tem plano Anual, inclui personal
        TreinoPersonal personalBeatriz = new TreinoPersonal(
                beatriz, carla, CategoriaAula.MUSCULACAO, "Quarta-feira às 08h", 60
        );
        academia.agendarPersonal(personalBeatriz);

        // João tem plano Mensal, não inclui personal, deve bloquear
        TreinoPersonal personalJoao = new TreinoPersonal(
                joao, diego, CategoriaAula.FUNCIONAL, "Quinta-feira às 18h", 45
        );
        academia.agendarPersonal(personalJoao);
        System.out.println();

        // Manutenção em lote
        academia.realizarManutencaoEmLote();
        System.out.println();

        // Listagens polimórficas
        academia.listarPessoas();
        System.out.println();
        academia.listarAulas();
        System.out.println();

        // Relatório final
        RelatorioMetricas relatorio = academia.gerarRelatorioMetricas();
        relatorio.imprimir();
    }
}
