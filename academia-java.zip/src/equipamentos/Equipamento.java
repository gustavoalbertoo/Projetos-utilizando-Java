package equipamentos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import enums.StatusEquipamento;

// Equipamento físico da academia (esteira, supino, etc)
public class Equipamento implements Manutivel {

    private final String numeroSerie;
    private final String nomeItem;
    private StatusEquipamento status;
    private final List<String> historicoReparos = new ArrayList<>();

    public Equipamento(String numeroSerie, String nomeItem, StatusEquipamento status) {
        this.numeroSerie = numeroSerie;
        this.nomeItem = nomeItem;
        this.status = status;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    @Override
    public String getNomeItem() {
        return nomeItem;
    }

    public StatusEquipamento getStatus() {
        return status;
    }

    @Override
    public List<String> getHistoricoReparos() {
        return Collections.unmodifiableList(historicoReparos);
    }

    @Override
    public boolean realizarReparo(String descricaoReparo) {
        // só reparamos o que está realmente com defeito
        if (status != StatusEquipamento.DEFEITUOSO) {
            return false;
        }

        historicoReparos.add(descricaoReparo);
        status = StatusEquipamento.FUNCIONANDO;
        return true;
    }

    @Override
    public String toString() {
        return String.format("%s (nº série %s) - status: %s", nomeItem, numeroSerie, status);
    }
}
