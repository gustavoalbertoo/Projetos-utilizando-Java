package equipamentos;

import java.util.List;

// Contrato para itens que podem passar por manutenção (hoje só Equipamento usa)
public interface Manutivel {

    String getNomeItem();

    List<String> getHistoricoReparos();

    // Retorna false quando o item não está em condição de ser reparado
    boolean realizarReparo(String descricaoReparo);
}
