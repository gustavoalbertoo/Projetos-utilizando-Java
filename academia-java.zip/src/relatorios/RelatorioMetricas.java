package relatorios;

// Retrato consolidado da academia em um dado momento
public record RelatorioMetricas(
        int totalAlunos,
        int totalInstrutores,
        int aulasAtivas,
        int sessoesPersonalAgendadas,
        int equipamentosDefeituosos,
        double receitaMensalEstimada
) {

    public void imprimir() {
        System.out.println("----- Relatório de Métricas -----");
        System.out.println("Total de alunos: " + totalAlunos);
        System.out.println("Total de instrutores: " + totalInstrutores);
        System.out.println("Aulas ativas (coletivas + personal): " + aulasAtivas);
        System.out.println("Sessões de personal agendadas: " + sessoesPersonalAgendadas);
        System.out.println("Equipamentos com defeito: " + equipamentosDefeituosos);
        System.out.printf("Receita mensal estimada: R$ %.2f%n", receitaMensalEstimada);
        System.out.println("----------------------------------");
    }
}
