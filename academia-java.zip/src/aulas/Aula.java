package aulas;

import modelo.Instrutor;
import enums.CategoriaAula;

// Contrato base para qualquer tipo de aula (coletiva ou personal)
public interface Aula {

    String getNomeAula();

    Instrutor getInstrutor();

    CategoriaAula getCategoria();

    String getDescricao();
}
