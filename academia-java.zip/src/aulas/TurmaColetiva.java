package aulas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import modelo.Aluno;
import modelo.Instrutor;
import enums.CategoriaAula;

// Aula em grupo, com vários alunos ao mesmo tempo
public class TurmaColetiva implements Aula {

    private final String nomeAula;
    private final Instrutor instrutor;
    private final CategoriaAula categoria;
    private final String descricao;
    private final int capacidadeMaxima;
    private final List<Aluno> alunosInscritos = new ArrayList<>();

    public TurmaColetiva(String nomeAula, Instrutor instrutor, CategoriaAula categoria,
                          String descricao, int capacidadeMaxima) {
        this.nomeAula = nomeAula;
        this.instrutor = instrutor;
        this.categoria = categoria;
        this.descricao = descricao;
        this.capacidadeMaxima = capacidadeMaxima;
    }

    @Override
    public String getNomeAula() {
        return nomeAula;
    }

    @Override
    public Instrutor getInstrutor() {
        return instrutor;
    }

    @Override
    public CategoriaAula getCategoria() {
        return categoria;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    public int getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public List<Aluno> getAlunosInscritos() {
        return Collections.unmodifiableList(alunosInscritos);
    }

    // Retorna false se a turma já estiver cheia
    public boolean matricularAluno(Aluno aluno) {
        if (alunosInscritos.size() >= capacidadeMaxima) {
            return false;
        }

        alunosInscritos.add(aluno);
        return true;
    }
}
