package aulas;

import modelo.Aluno;
import modelo.Instrutor;
import enums.CategoriaAula;

// Sessão individual de personal trainer entre aluno e instrutor
public class TreinoPersonal implements Aula {

    private final Aluno aluno;
    private final Instrutor instrutor;
    private final CategoriaAula categoria;
    private final String horarioAgendado;
    private final int duracaoMinutos;

    public TreinoPersonal(Aluno aluno, Instrutor instrutor, CategoriaAula categoria,
                           String horarioAgendado, int duracaoMinutos) {
        this.aluno = aluno;
        this.instrutor = instrutor;
        this.categoria = categoria;
        this.horarioAgendado = horarioAgendado;
        this.duracaoMinutos = duracaoMinutos;
    }

    @Override
    public String getNomeAula() {
        return "Personal com " + aluno.getNome();
    }

    @Override
    public Instrutor getInstrutor() {
        return instrutor;
    }

    @Override
    public CategoriaAula getCategoria() {
        return categoria;
    }

    @Override
    public String getDescricao() {
        return String.format("Sessão individual (%d min) agendada para %s", duracaoMinutos, horarioAgendado);
    }

    public Aluno getAluno() {
        return aluno;
    }

    public String getHorarioAgendado() {
        return horarioAgendado;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }
}
