package modelo;

// Classe base para quem é cadastrado na academia (Aluno ou Instrutor)
public abstract class Pessoa {

    protected String nome;
    protected String email;
    protected String telefone;
    protected String cpf;
    protected String endereco;

    public Pessoa(String nome, String email, String telefone, String cpf, String endereco) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.cpf = cpf;
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    // Cada subclasse descreve a si mesma do seu jeito
    public abstract String descricao();
}
