package modelo;

import enums.NivelExperiencia;

// Aluno matriculado na academia
public class Aluno extends Pessoa {

    private final String matricula;
    private PlanoAssinatura plano;
    private NivelExperiencia nivel;
    private double pesoKg;
    private double alturaMetros;
    private String objetivoTreino;
    private boolean possuiAtestadoMedico;

    public Aluno(String nome, String email, String telefone, String cpf, String endereco,
                 String matricula, PlanoAssinatura plano, NivelExperiencia nivel,
                 double pesoKg, double alturaMetros, String objetivoTreino,
                 boolean possuiAtestadoMedico) {
        super(nome, email, telefone, cpf, endereco);
        this.matricula = matricula;
        this.plano = plano;
        this.nivel = nivel;
        this.pesoKg = pesoKg;
        this.alturaMetros = alturaMetros;
        this.objetivoTreino = objetivoTreino;
        this.possuiAtestadoMedico = possuiAtestadoMedico;
    }

    public String getMatricula() {
        return matricula;
    }

    public PlanoAssinatura getPlano() {
        return plano;
    }

    public void setPlano(PlanoAssinatura plano) {
        this.plano = plano;
    }

    public NivelExperiencia getNivel() {
        return nivel;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public double getAlturaMetros() {
        return alturaMetros;
    }

    public String getObjetivoTreino() {
        return objetivoTreino;
    }

    public boolean isPossuiAtestadoMedico() {
        return possuiAtestadoMedico;
    }

    @Override
    public String descricao() {
        return String.format("Aluno %s (matrícula %s) - nível %s, objetivo: %s, plano: %s",
                nome, matricula, nivel, objetivoTreino, plano.getNome());
    }
}
