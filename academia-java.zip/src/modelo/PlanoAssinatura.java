package modelo;

// Plano de assinatura da academia (Mensal, Trimestral, Anual...)
public class PlanoAssinatura {

    private final String nome;
    private final boolean incluiPersonal;
    private final int limiteAulasColetivas; // -1 = ilimitado
    private final int duracaoMeses;
    private final double valorMensal;

    public PlanoAssinatura(String nome, boolean incluiPersonal, int limiteAulasColetivas,
                            int duracaoMeses, double valorMensal) {
        this.nome = nome;
        this.incluiPersonal = incluiPersonal;
        this.limiteAulasColetivas = limiteAulasColetivas;
        this.duracaoMeses = duracaoMeses;
        this.valorMensal = valorMensal;
    }

    public String getNome() {
        return nome;
    }

    public boolean isIncluiPersonal() {
        return incluiPersonal;
    }

    public int getLimiteAulasColetivas() {
        return limiteAulasColetivas;
    }

    public int getDuracaoMeses() {
        return duracaoMeses;
    }

    public double getValorMensal() {
        return valorMensal;
    }

    @Override
    public String toString() {
        String limite = limiteAulasColetivas < 0 ? "ilimitadas" : (limiteAulasColetivas + " por mês");
        return String.format("%s (%d meses, R$ %.2f/mês, personal: %s, aulas coletivas: %s)",
                nome, duracaoMeses, valorMensal, incluiPersonal ? "sim" : "não", limite);
    }
}
