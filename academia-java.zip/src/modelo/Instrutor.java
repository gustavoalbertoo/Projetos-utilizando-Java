package modelo;

import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

// Instrutor da academia, identificado pelo CREF (registro profissional)
public class Instrutor extends Pessoa {

    private final String cref;
    private String especialidade;
    private int anoIngresso;
    private double salario;
    private final List<String> disponibilidadeSemanal;

    public Instrutor(String nome, String email, String telefone, String cpf, String endereco,
                      String cref, String especialidade, int anoIngresso, double salario,
                      List<String> disponibilidadeSemanal) {
        super(nome, email, telefone, cpf, endereco);
        this.cref = cref;
        this.especialidade = especialidade;
        this.anoIngresso = anoIngresso;
        this.salario = salario;
        this.disponibilidadeSemanal = new ArrayList<>(disponibilidadeSemanal);
    }

    public String getCref() {
        return cref;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public int getAnoIngresso() {
        return anoIngresso;
    }

    public double getSalario() {
        return salario;
    }

    public List<String> getDisponibilidadeSemanal() {
        return Collections.unmodifiableList(disponibilidadeSemanal);
    }

    @Override
    public String descricao() {
        return String.format("Instrutor %s (CREF %s) - especialidade: %s, na academia desde %d",
                nome, cref, especialidade, anoIngresso);
    }
}
